/* 
 * File:   DeMerittA7.h
 * Author: Mini_Mole
 *
 * Created on October 14, 2012, 6:20 PM
 */

#ifndef DEMERITTA7_H_INCLUDED
#define	DEMERITTA7_H_INCLUDED

char*** update(char***, int x, int y);
void display(char***, int x, int y);
char*** creater(int x, int y);

#endif	/* DEMERITTA7_H */


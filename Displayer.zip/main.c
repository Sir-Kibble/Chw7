#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "DeMerittA7.h"
int main(int argc, char** argv) {
    //printf("hi@");
    //char**   board = 
    int x,y,t;
    x = 30;
    y = 30;
    char*** board = creater(x,y);
    //char*** temp = board;
    display(board,x,y);
    do{
    
    
    //system("clear");
    
    board = update(board,x,y);
    printf("--------------------------------------------\n");
    display(board,x,y);
    t = 0;
    scanf("%i",&t);
    }while(t!= 0);
    return (EXIT_SUCCESS);
}//end main

